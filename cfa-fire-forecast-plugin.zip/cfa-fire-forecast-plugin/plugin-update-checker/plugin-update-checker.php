<?php
/**
 * Plugin Update Checker Library 5.4
 * http://w-shadow.com/
 *
 * Copyright 2024 Janis Elsts
 * Released under the MIT license. See license.txt for details.
 */

require dirname(__FILE__) . '/load-v5p4.php';